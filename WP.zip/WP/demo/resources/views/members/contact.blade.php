@extends('members.layout')
@section('content')

<body id="contact">
	<img src="images/footer-img.png" class="contact-img">
	<div class="title-text">
		<p>CONTACT</p>
		<h1>Vist Our Club</h1>	
	</div>
	<div class="contact-row">
		<div class="contact-left">
			<h1>Opening Hours</h1>
			<p><i class="fa fa-clock-o"></i>Monday to Friday -9am to 9pm</p>
			<p><i class="fa fa-clock-o"></i>Saturday to Sunday -8am to 11pm</p>
		</div>
		<div class="contact-left">
			<h1>Get In Touch</h1>
			<p><i class="fa fa-map-marker"></i>138/B, block F, Road 2, Uposhohor, sylhet</p>
			<p><i class="fa fa-paper-plane"></i>fitnessClub@gmail.com</p>
			<p><i class="fa fa-phone"></i>+880 1729457235</p>
		</div>
	</div>
	<div class="social-links">
		<i class="fa fa-facebook"></i>
		<i class="fa fa-instagram"></i>
		<i class="fa fa-twitter"></i>
		<i class="fa fa-youtube-play"></i>
		
	</div>
</body>