@extends('members.layout')

@section('content')

<div class="member-Profile">
	<br>
	<h1 style="text-shadow: 2px 2px 5px Aqua;font-size: 50px;text-align: center">Membership details</h1>
	<div class="line-wrap">
		<div class="line"></div>
		<h2 style="color: white"><center>Members Profile</center></h2>
		<br>

	<table class="member-table">
		<tr style="background-color: #000066;color: white;height: 50">
			<th> Member ID </th>
			<th> Full Name </th>
			<th> Gender </th>
			<th> Birth Date </th>
			<th> Age </th>
			<th> Blood Group </th>
			<th> Phone Number </th>
			<th> Email </th>
			<th> Address </th>
			<th> Action </th>
		</tr>

		@foreach ($members as $member)
		<tr style="background-color: #CCFFCC"> 
			<td>{{$member->member_id}} </td>
			<td>{{$member->name}} </td>
			<td>{{$member->gender}} </td>
			<td>{{$member->birth_date}} </td>
			<td>{{$member->age}} </td>
			<td>{{$member->blood_group}} </td>
			<td>{{$member->phone_no}} </td>
			<td>{{$member->email}} </td>
			<td>{{$member->address}} </td>

			<td>
				<form action="{{ route('members.destroy', $member->id)}}" method="POST">
					
					<a href="{{ route('members.edit', $member->id)}}" style="font-size: 25px;color: orange"><i class="fa fa-edit"></i></a>					
					@csrf
                    @method('DELETE') 

					<button type="submit" style="font-size: 23px;color: red" ><i class="fa fa-trash"></i></button>
				</form>
			</td>
		</tr>
		@endforeach 

	</table>
    </div>
</div>