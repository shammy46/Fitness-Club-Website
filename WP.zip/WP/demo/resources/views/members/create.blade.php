@extends('members.layout')
@section('content')

<body class="create-box">
    <p class="box">Believe In<br>Yourself<br> &<br>You Will Be Unstopable</p>
    <div class="form">
        <br>
        <center><h2> Membership Application </h2>
            
        <p> To apply for the membership please complete the form below: </p>
        </center><br>
        <hr><br>

        <form action="{{route('members.store')}}" method="POST">
            @csrf
            <table class="text">
                <tr>
                    <td> Member ID:</td>
                    <td>
                        <input class="holdercolor" type="text" name="member_id" placeholder="XXX-XXX-XXX">
                        <br>
                        <span class="field_error">
                            @error('member_id')
                            {{$message}}
                            @enderror
                        </span>
                    </td>
                </tr>
                <tr>
                    <td> Full Name: </td>
                    <td><input class="holdercolor" type="text" name="name" placeholder="Full Name">
                        <br>
                        <span class="field_error">
                            @error('name')
                            {{$message}}
                            @enderror
                        </span>

                    </td>
                </tr>

                <tr>
                    
                    <td><p>Please select your gender:</p>
                    <td>
                    <input type="radio" id="male" name="gender" value="male">
                    <label for="male">Male</label><br>
                    <input type="radio" id="female" name="gender" value="female">
                    <label for="female">Female</label><br>
                    <input type="radio" id="other" name="gender" value="other">
                    <label for="other">Other</label>
                        <br>
                        <span class="field_error">
                            @error('gender')
                            {{$message}}
                            @enderror
                        </span>

                    </td>
                </tr>

                <tr>
                    <td> Birth Date:</td>
                    <td><input class="holdercolor" type="text" name="birth_date" placeholder="dd/mm/yy">
                     <br>
                     <span class="field_error">
                        @error('birth_date')
                        {{$message}}
                        @enderror
                    </span>

                    </td>
                </tr>

                <tr>
                    <td> Age:</td>
                    <td><input class="holdercolor" type="text" name="age" placeholder="age">
                     <br>
                     <span class="field_error">
                        @error('age')
                        {{$message}}
                        @enderror
                    </span>

                    </td>
                </tr>

                <tr>
                    <td> Blood Group:</td>
                    <td><input class="holdercolor" type="text" name="blood_group" placeholder="blood group">
                     <br>
                     <span class="field_error">
                        @error('blood_group')
                        {{$message}}
                        @enderror
                    </span>

                    </td>
                </tr>

                <tr>
                    <td> Phone No: </td>
                    <td><input class="holdercolor" type="text" name="phone_no" placeholder="phoneNo">
                     <br>
                     <span class="field_error">
                        @error('phone_no')
                        {{$message}}
                        @enderror
                    </span>

                    </td>
            </tr>
            <tr>

               <td> Email: </td>

               <td><input class="holdercolor" type="text" name="email" placeholder="yourname@gmail.com">
           <br>
            <span class="field_error">
                @error('email')
                {{$message}}
                @enderror
                </span>

                </td>
            </tr>


            <tr>
            <td> Address: </td>

            <td><input class="holdercolor" type="text" name="address" placeholder="Address">
            <br>
            <span class="field_error">
                @error('address')
                {{$message}}
                @enderror
            </span>

                </td>
            </tr>

            <tr>
            <td></td>
            <td><button class="button" type="submit" > Submit </button>
            </td>
            </span>

            </tr>

         </table>

    <br><br>

    </form>


</div>
</body>
