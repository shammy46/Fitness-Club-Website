@extends('members.layout')
@section('content')


<body>
	<div id="class-box">
		<div class="classes">
			<img src="/images/class.jpg">
			<div class="centered">Keep Fit Lose Weight & Have Fun</div>	
		</div>
		<br>
		<h2>Class Description</h2>
		<div class="class-tbl">
			<h3>BOXFIT</h3>
			<p>High energy cardio workout using pads and boxing gloves. A mixture of HIIT, circuits paired with boxing techniques to work out like a boxer with our motivated and focussed instructor. An upbeat class open to all abilities.</p>
			<br>
			<h3>CORE, TONE AND STRETCH</h3>
			<p>A full body workout incorporating free weights, body weight and resistance bands and finishing with 15 minutes stretching to ease tension.</p>
			<br>
			<h3>CORE AND FLEX</h3>
			<p>A class that focuses on your core strength with a combination of 30 minutes of resistance and floor based exercises and finishing with 15 minutes of stretching exercises to leave you feeling toned and relaxed.</p>
			<br>
			<h3>GYM FLOOR KETTLE BELLS</h3>
			<p>Express Kettle Bell class on the gym floor.</p>
			<br>
			<h3>YOGA</h3>
			<p>A gentle way to improve posture, balance and coordination developing harmony in the body and mind</p>
			<br>
			<h3>BODYFLOW</h3>
			<p>A class focusing on flexibility and posture combining the disciplines of Pilates and Tai Chi</p>
			<br>
			<h3>BODYBAR</h3>
			<p>A weights based class using a barbel and plates to strengthen and tone</p>
			<br>
			<h3>GYM FLOOR CARDIO CIRCUITS</h3>
			<p>Gym Floor express circuits class utilising the cardio equipment such as the running machines, rowers and cross trainers.</p>
			<br>
			<h3>GYM FLOOR OMNIA RIG</h3>
			<p>Express Omnia Rig Class held in the functional fitness area on the gym floor.</p>
			<br>
			<h3>METAFIT</h3>
			<p>A body weight training class that boosts metabolism for upto 24 hours, so you can even burn fat in your sleep!</p>

			
		</div>
	</div>

</body>