@extends('members.layout')
@section('content')



<body class="edit-box">
    <p class="box">Passion<br>Without Action<br> &<br>Remains A Dream </p>
	<div class="form">
	    <br>		
        <center><h2> Membership Application </h2>
        <p> Complete all the required details given below: </p>
        </center><br>
        <hr><br>
        
	<form action="{{route('members.update',$member->id) }}" method="POST">
 	 	@csrf
 	 	@method('PUT')
 	 	<table class="text">
 	 		<tr>
 	 			<td>Member ID:</td>
 	 			<td><input type="text" name="member_id" placeholder="Member ID (XXX-XXX-XXX)" value="{{$member->member_id}}"> 
		        <br>
		        <span class="field_error">
                @error('member_id')
                {{$message}}
                @enderror
            </span>
		        </td>
		    </tr>


		    <tr>
		        <td>Name:</td>
		        <td><input type="text" name="name" placeholder="Full Name" value="{{$member->name}}">
		        <br>
		        <span class="field_error">
                @error('name')
                {{$message}}
                @enderror
            </span>
	            </td>
            </tr>

            <tr>
		        <td>Gender:</td>
	        	<td><input type="text" name="gender" value="{{$member->gender}}">
		        <br>
		        <span class="field_error">
                @error('gender')
                {{$message}}
                @enderror
            </span>
	            </td>
            </tr>

            <tr>
            	<td>Birth Date:</td>
            	<td><input type="text" name="birth_date" placeholder="dd/mm/yy" value="{{$member->birth_date}}">
		        <br>
		        <span class="field_error">
                @error('birth_date')
                {{$message}}
                @enderror
            </span>
		        </td>
		    </tr>

		    <tr>
            	<td>Age:</td>
            	<td><input type="text" name="age" placeholder="age" value="{{$member->age}}">
		        <br>
		        <span class="field_error">
                @error('age')
                {{$message}}
                @enderror
            </span>
		        </td>
		    </tr>

		    <tr>
            	<td>Blood Group:</td>
            	<td><input type="text" name="blood_group" placeholder="blood group" value="{{$member->blood_group}}">
		        <br>
		        <span class="field_error">
                @error('blood_group')
                {{$message}}
                @enderror
            </span>
		        </td>
		    </tr>

		    <tr>
		    	<td>Phone Number:</td>
		    	<td><input type="text" name="phone_no" placeholder="Phone" value="{{$member->phone_no}}">
		        <br>
		        <span class="field_error">
                @error('phone_no')
                {{$message}}
                @enderror
            </span>
		        </td>
		    </tr>

		    <tr>
		    	<td>Email address:</td>
		    	<td><input type="text" name="email" placeholder="yourname@gmail.com" value="{{$member->email}}">
		        <br>
		        <span class="field_error">
                @error('email')
                {{$message}}
                @enderror
            </span>
		        </td>
		    </tr>

		    <tr>
		    	<td>Address:</td>
		    	<td> <input type="text" name="address" placeholder="Address" value="{{$member->address}}">
		    	<br>
		    	<span class="field_error">
                @error('address')
                {{$message}}
                @enderror
            </span>
            <br>
		        </td>
		    </tr>
		    <tr>
		    <td></td>
		    <td><button type="submit" >Update</button>
		    </td>
		</tr>
	</table>

	</form>

	</div>
</body>

