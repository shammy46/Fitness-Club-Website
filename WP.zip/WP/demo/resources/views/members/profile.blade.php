@extends('members.layout')
@section('content')



<header id="banner">
    <div class="navBar">
        <ul>
          <li><a href="{{url('/')}}">HOME</a></li>
          <li><a href="{{url('/features')}}">FEATURES</a></li>
          <li><a href="{{url('/service')}}">SERVICE</a></li>
          <li><a href="{{url('/members')}}">MEMBERS</a></li>
          <li><a href="{{url('/classes')}}">CLASSES</a></li>
          <li><a href="{{url('/contact')}}">CONTACT</a></li>
        </ul>
    </div>

	<h2>Fitness Club</h2>
	<div class="home">
		<h1>Get fit & healthy</h1>
		<p>Fitness Club isn't anything like a regular chain center. The class based sessions are challangeing, innovative and fun led by highly talented trainers.</p>
	</div>
    <div class="banner-btn">
                <a href="{{ route('members.create') }}"><span></span>Join Us</a>
            </div>

</header>