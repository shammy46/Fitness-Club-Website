<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Member;

class MemberController extends Controller
{

    public function profile(){
        return view('members.profile'); 

    }

    public function features(){
        return view('members.features'); 

    }

    public function service(){
        return view('members.service'); 
    }

    public function contact(){
        return view('members.contact'); 

    }

    public function classes(){
        return view('members.classes'); 

    }

    public function index(){
        $members = Member::latest()->paginate(30);

        return view('members.index', compact('members'));
    }

     public function create(){

        return view('members.create');
    }

    public function store(Request $request){
        $request->validate([
            'member_id' => 'required',
            'name'=>'required',
            'gender'=>'required',
            'birth_date'=>'required',
            'age'=>'required',
            'blood_group'=>'required',
            'phone_no'=>'required',
            'email'=>'required',
            'address'=>'required',
        ]);

        Member::create($request->all());

        return redirect()->route('members.index')->with('success', 'Profile Created Successflly!');
    }

    public function edit(Member $member){
        return view('members.edit', compact('member'));
    }


    public function update(Request $request, Member $member){
        $request->validate([
            'member_id' => 'required',
            'name'=>'required',
            'gender'=>'required',
            'birth_date'=>'required',
            'age'=>'required',
            'blood_group'=>'required',
            'phone_no'=>'required',
            'email'=>'required',
            'address'=>'required',
        ]);

        
        $member->update($request->all());

        return redirect()->route('members.index')->with('success', 'Profile Updated Successflly!');
    }

    public function destroy(Member $member){

        $member->delete();
        return redirect()->route('members.index')->with('success', 'Profile Deleted Successflly!');
    }
}
