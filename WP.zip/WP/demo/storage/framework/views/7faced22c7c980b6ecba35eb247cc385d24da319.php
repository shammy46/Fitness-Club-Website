
<?php $__env->startSection('content'); ?>



<body class="edit-box">
    <p class="box">Passion<br>Without Action<br> &<br>Remains A Dream </p>
	<div class="form">
	    <br>		
        <center><h2> Membership Application </h2>
        <p> Complete all the required details given below: </p>
        </center><br>
        <hr><br>
        
	<form action="<?php echo e(route('members.update',$member->id)); ?>" method="POST">
 	 	<?php echo csrf_field(); ?>
 	 	<?php echo method_field('PUT'); ?>
 	 	<table class="text">
 	 		<tr>
 	 			<td>Member ID:</td>
 	 			<td><input type="text" name="member_id" placeholder="Member ID (XXX-XXX-XXX)" value="<?php echo e($member->member_id); ?>"> 
		        <br>
		        <span class="field_error">
                <?php $__errorArgs = ['member_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
		        </td>
		    </tr>


		    <tr>
		        <td>Name:</td>
		        <td><input type="text" name="name" placeholder="Full Name" value="<?php echo e($member->name); ?>">
		        <br>
		        <span class="field_error">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
	            </td>
            </tr>

            <tr>
		        <td>Gender:</td>
	        	<td><input type="text" name="gender" value="<?php echo e($member->gender); ?>">
		        <br>
		        <span class="field_error">
                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
	            </td>
            </tr>

            <tr>
            	<td>Birth Date:</td>
            	<td><input type="text" name="birth_date" placeholder="dd/mm/yy" value="<?php echo e($member->birth_date); ?>">
		        <br>
		        <span class="field_error">
                <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
		        </td>
		    </tr>

		    <tr>
            	<td>Age:</td>
            	<td><input type="text" name="age" placeholder="age" value="<?php echo e($member->age); ?>">
		        <br>
		        <span class="field_error">
                <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
		        </td>
		    </tr>

		    <tr>
            	<td>Blood Group:</td>
            	<td><input type="text" name="blood_group" placeholder="blood group" value="<?php echo e($member->blood_group); ?>">
		        <br>
		        <span class="field_error">
                <?php $__errorArgs = ['blood_group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
		        </td>
		    </tr>

		    <tr>
		    	<td>Phone Number:</td>
		    	<td><input type="text" name="phone_no" placeholder="Phone" value="<?php echo e($member->phone_no); ?>">
		        <br>
		        <span class="field_error">
                <?php $__errorArgs = ['phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
		        </td>
		    </tr>

		    <tr>
		    	<td>Email address:</td>
		    	<td><input type="text" name="email" placeholder="yourname@gmail.com" value="<?php echo e($member->email); ?>">
		        <br>
		        <span class="field_error">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
		        </td>
		    </tr>

		    <tr>
		    	<td>Address:</td>
		    	<td> <input type="text" name="address" placeholder="Address" value="<?php echo e($member->address); ?>">
		    	<br>
		    	<span class="field_error">
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
            <br>
		        </td>
		    </tr>
		    <tr>
		    <td></td>
		    <td><button type="submit" >Update</button>
		    </td>
		</tr>
	</table>

	</form>

	</div>
</body>


<?php echo $__env->make('members.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WP\demo\resources\views/members/edit.blade.php ENDPATH**/ ?>