

<?php $__env->startSection('content'); ?>

<div class="member-Profile">
	<br>
	<h1 style="text-shadow: 2px 2px 5px Aqua;font-size: 50px;text-align: center">Membership details</h1>
	<div class="line-wrap">
		<div class="line"></div>
		<h2 style="color: white"><center>Members Profile</center></h2>
		<br>

	<table class="member-table">
		<tr style="background-color: #000066;color: white;height: 50">
			<th> Member ID </th>
			<th> Full Name </th>
			<th> Gender </th>
			<th> Birth Date </th>
			<th> Age </th>
			<th> Blood Group </th>
			<th> Phone Number </th>
			<th> Email </th>
			<th> Address </th>
			<th> Action </th>
		</tr>

		<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr style="background-color: #CCFFCC"> 
			<td><?php echo e($member->member_id); ?> </td>
			<td><?php echo e($member->name); ?> </td>
			<td><?php echo e($member->gender); ?> </td>
			<td><?php echo e($member->birth_date); ?> </td>
			<td><?php echo e($member->age); ?> </td>
			<td><?php echo e($member->blood_group); ?> </td>
			<td><?php echo e($member->phone_no); ?> </td>
			<td><?php echo e($member->email); ?> </td>
			<td><?php echo e($member->address); ?> </td>

			<td>
				<form action="<?php echo e(route('members.destroy', $member->id)); ?>" method="POST">
					
					<a href="<?php echo e(route('members.edit', $member->id)); ?>" style="font-size: 25px;color: orange"><i class="fa fa-edit"></i></a>					
					<?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?> 

					<button type="submit" style="font-size: 23px;color: red" ><i class="fa fa-trash"></i></button>
				</form>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

	</table>
    </div>
</div>
<?php echo $__env->make('members.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WP\demo\resources\views/members/index.blade.php ENDPATH**/ ?>