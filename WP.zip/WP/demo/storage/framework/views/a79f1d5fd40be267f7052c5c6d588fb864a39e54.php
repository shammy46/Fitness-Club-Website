
<?php $__env->startSection('content'); ?>

<body id="features">
	<div class="title-text">
	<br><br>
	<p>Features</p>
	<h1>Why Choose us</h1>	
	</div>
	<div class="float-container">
		      <div class="float-child1">
		
					  <div class="features">
						<h1>Free Induction</h1>
							<div class="features-box">
								<p>Our Staff will show round our facilities and take and take help anytime.</p>
							</div>
					  </div>

					  <div class="features">
						 <h1>Personal Training</h1>
							 <div class="features-box">
								 <p>Meet the team that will get you fit.</p>
							 </div>
					  </div>

					  <div class="features">
						 <h1>Club Cycle</h1>
							 <div class="features-box">
								 <p>Sedicated cycle room with Technogym CYCLE CONNECT.</p>
							 </div>
					  </div>

					  <div class="features">
						<h1>Fitness Classes</h1>
							<div class="features-box">
								<p>Amazing results in double quick time.</p>
							</div>
					  </div>
			</div>

			<div class="float-child2">
				<img src="images/features.jpg" >  
		   </div>
			
	</div>
		
		

</body>
<?php echo $__env->make('members.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WP\demo\resources\views/members/features.blade.php ENDPATH**/ ?>