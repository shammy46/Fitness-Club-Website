
<?php $__env->startSection('content'); ?>

<body class="create-box">
    <p class="box">Believe In<br>Yourself<br> &<br>You Will Be Unstopable</p>
    <div class="form">
        <br>
        <center><h2> Membership Application </h2>
            
        <p> To apply for the membership please complete the form below: </p>
        </center><br>
        <hr><br>

        <form action="<?php echo e(route('members.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <table class="text">
                <tr>
                    <td> Member ID:</td>
                    <td>
                        <input class="holdercolor" type="text" name="member_id" placeholder="XXX-XXX-XXX">
                        <br>
                        <span class="field_error">
                            <?php $__errorArgs = ['member_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </td>
                </tr>
                <tr>
                    <td> Full Name: </td>
                    <td><input class="holdercolor" type="text" name="name" placeholder="Full Name">
                        <br>
                        <span class="field_error">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>

                    </td>
                </tr>

                <tr>
                    
                    <td><p>Please select your gender:</p>
                    <td>
                    <input type="radio" id="male" name="gender" value="male">
                    <label for="male">Male</label><br>
                    <input type="radio" id="female" name="gender" value="female">
                    <label for="female">Female</label><br>
                    <input type="radio" id="other" name="gender" value="other">
                    <label for="other">Other</label>
                        <br>
                        <span class="field_error">
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>

                    </td>
                </tr>

                <tr>
                    <td> Birth Date:</td>
                    <td><input class="holdercolor" type="text" name="birth_date" placeholder="dd/mm/yy">
                     <br>
                     <span class="field_error">
                        <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>

                    </td>
                </tr>

                <tr>
                    <td> Age:</td>
                    <td><input class="holdercolor" type="text" name="age" placeholder="age">
                     <br>
                     <span class="field_error">
                        <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>

                    </td>
                </tr>

                <tr>
                    <td> Blood Group:</td>
                    <td><input class="holdercolor" type="text" name="blood_group" placeholder="blood group">
                     <br>
                     <span class="field_error">
                        <?php $__errorArgs = ['blood_group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>

                    </td>
                </tr>

                <tr>
                    <td> Phone No: </td>
                    <td><input class="holdercolor" type="text" name="phone_no" placeholder="phoneNo">
                     <br>
                     <span class="field_error">
                        <?php $__errorArgs = ['phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>

                    </td>
            </tr>
            <tr>

               <td> Email: </td>

               <td><input class="holdercolor" type="text" name="email" placeholder="yourname@gmail.com">
           <br>
            <span class="field_error">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>

                </td>
            </tr>


            <tr>
            <td> Address: </td>

            <td><input class="holdercolor" type="text" name="address" placeholder="Address">
            <br>
            <span class="field_error">
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>

                </td>
            </tr>

            <tr>
            <td></td>
            <td><button class="button" type="submit" > Submit </button>
            </td>
            </span>

            </tr>

         </table>

    <br><br>

    </form>


</div>
</body>

<?php echo $__env->make('members.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WP\demo\resources\views/members/create.blade.php ENDPATH**/ ?>