<html>
<head> 
	<title> CSE 323: Web Programming Laravel Project</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>
    *{
      margin: 0;
      padding: 0;
    }

    /* Home */
    #banner {
            background-image:linear-gradient(rgba(0,0,0,0.5),#0090),url('/images/home.jpg');
            background-size: cover;
            background-position: center;
            height: 100vh;
    }

    #banner h2 {
        text-shadow: 2px 2px 5px black;
        font-size: 40px;
        text-align: left;
        color: green;
        padding-top: 20px;
        padding-left: 30px;
    }
    
    .navBar ul{
        float: right;
        list-style-type: none;
        margin-top: 35px;
        margin-right: 40px;

    }

    .navBar ul li {
        display: inline-block;
    }

    .navBar ul li a{
        text-decoration: none;
        color: #fff;
        padding: 10px 30px;
        border: 1px solid #fff ;
        transition: 0.6s ease;
    }

    .navBar ul li a:hover{
        background-color: #fff;
        color: 000;
    }

    .home h1{
      font-size: 100px;
      text-align: left ;
      color: coral;
      position:absolute; 
      left:80px; 
      top:240px; 
        text-shadow: 2px 2px 5px black;   
    }
    .home p{
      font-size: 20px;
      color: white;
      position:absolute; 
      left:180px; 
      top:380px;   
      width:50%;
    }
    
    .banner-btn {
            left:160px; 
            top:450px;
            position: absolute;

        }
        .banner-btn a{
            width: 80px;
            font-size: 20px;
            text-decoration: none;
            display:inline-block;
            margin: 0 15px;
            padding: 12px 20px;
            color: #fff;
            border: .5px solid #fff;
            position: relative;
            z-index: 1;
            transition: color 0.3s;
        }
        .banner-btn a span {
            width: 0%;
            height: 100%;
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: -1;
            background: #fff;
            transition: 0.5s;

        }
        .banner-btn a:hover span{
            width: 100%;

        }
        .banner-btn a:hover{
            color:#000; 
        }

    /*features */
    #features{
      width: 100%;
      
    }
    .title-text{
      text-align: center;
      
    }
    .title-text p{
    
      font-size: 30px;
      color: #009688;
      font-weight: bold;
      position: relative;
      display: inline-block;
      text-align: center;

    }
    
    .title-text h1{
      font-size: 40px;
      text-align: center;
    }
    
    
    .features h1{
      color: #009688;
      padding-left: 50px;
      padding-top: 50px;
    }
    .features-box p{
      
      text-align: center;
      font-size: 20px;
      font-style: italic;
      
    }

    }
    .float-container {
        border: 3px solid #fff;
        padding: 20px;
    }

    .float-child1 {
        width: 45%;
        float: left;
        padding: 20px;
        text-align: center;
        

      
    }  
    .float-child2 {
        width: 45%;
        float: right;
        padding: 20px;
         
      
  
    }  
    .float-child2 img{
      margin: auto;
      width: 70%;
      height: 60%;
      padding-left: 50px;
      padding-top: 50px;
    }



		
             .create-box {
             	background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url('/images/create.jpg');
             	background-repeat: no-repeat;
               background-attachment: fixed;
               background-size: cover;
             }

             .edit-box {
              background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url('/images/edit.jpg');
              background-repeat: no-repeat;
               background-attachment: fixed;
               background-size: cover;
             }


             .member-table{
		      background-color: white;
		    width: 1100;
        margin: auto;
        border-style: ridge;
        border-width: 7px;
        border-color: teal;
        overflow: hidden; 
        table-layout: auto; 
        height: 70vh;
	     }
       .member-profile{
        background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url('/images/members.jpg');
              background-repeat: no-repeat;
               background-attachment: fixed;
               background-size: cover;
               height: 100vh;
       }

       .line-wrap {
	    text-align: center;
    
			}

	    .line {
		display: inline-block;
	    background-color: white;
	    width: 80px;
	    height: 4px;
	    margin-top: 1rem;
	    margin-bottom: 1rem;

		}
		.box {
			font-size: 60px;
    	color: #99FF66;
    	position:absolute; 
    	left:150px; 
    	top:180px; 
    	text-align: center;
    	font-style: italic;
		}

	    .holdercolor {
        color: black;
		    }

        .form {
        background-color: black;
        position: absolute;
        top: 30px;
        bottom: 30px;
        width: 600px;
        right: 150px;
        margin: auto;
        color: white;


           }
           .text{
           	color: white;
           }

          .button {
        color: black;
        background-color: lightblue;
        cursor: pointer;    
        } 

          
       
	   }
	    .bar{
		text-align: center;
	
     	}


	   .field_error {
        color: red;
        }

    
       .field {
    	font-size: 80px;
        }
        /* classes */

        .classes{
    position: relative;
        text-align: center;
        color: white;
    
  }

  .classes img{
  width: 100%;
  height: 60%;
  filter: blur(2px);
  
  
  }
  .centered {
    position: absolute;
        top: 50%;
        left: 50%;
        font-size: 80px;
        transform: translate(-50%, -50%);

  }

  #class-box{
    text-align: center;


  }
  .class-tbl{
          margin: auto;
      width: 70%;
      border: 3px solid #73AD21;
      padding: 10px;
      background-color: #efefef;
      text-align: left;

  }


        /* contact */
        #contact{
    
      padding: 100px 0 20px;
      background-color: #efefef;
      position: relative;

  }
  .contact-row{
    width: 100%;
    margin: 80px 10px 10px 10px;
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
    
  }

  
  .contact-right{
    text-align: right;
  }

  .contact-left{
    text-align: left;
  }


  .contact-row h1{
    margin:10px 0;
  }

  .contact-row p{
    line-height: 35px;
  }

  .contact-left .fa,.contact-right .fa{
    font-size: 20px;
    color : #009688;
    margin: 10px;
  }

  .contact-img{
    max-width: 270px;
    opacity: 0.1;
    position: absolute;
    left: 40%;
    top: 8%;
    

  }

  .social-links{
    text-align: center;

  }
  .social-links .fa{
    width: 40px;
    height: 40px;
    font-size: 20px;
    line-height: 40px;
    border:1px solid #009688;
    margin: 40px 5px 0;
    color: #009688;
    cursor: pointer;
    transition: 0.5s; 
  }

  .social-links .fa:hover{
    background: #009688;
    color: #fff;
    transform: translateY(-7px);
  }

         


	</style>
</head>
<body>
	<div class="container"> 
		<?php echo $__env->yieldContent('content'); ?>
	

	</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\WP\demo\resources\views/members/layout.blade.php ENDPATH**/ ?>