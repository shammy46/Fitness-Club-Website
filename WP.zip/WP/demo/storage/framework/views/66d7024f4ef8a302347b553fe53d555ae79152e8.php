
<?php $__env->startSection('content'); ?>



<header id="banner">
    <div class="navBar">
        <ul>
          <li><a href="<?php echo e(url('/')); ?>">HOME</a></li>
          <li><a href="<?php echo e(url('/features')); ?>">FEATURES</a></li>
          <li><a href="<?php echo e(url('/service')); ?>">SERVICE</a></li>
          <li><a href="<?php echo e(url('/members')); ?>">MEMBERS</a></li>
          <li><a href="<?php echo e(url('/classes')); ?>">CLASSES</a></li>
          <li><a href="<?php echo e(url('/contact')); ?>">CONTACT</a></li>
        </ul>
    </div>

	<h2>Fitness Club</h2>
	<div class="home">
		<h1>Get fit & healthy</h1>
		<p>Fitness Club isn't anything like a regular chain center. The class based sessions are challangeing, innovative and fun led by highly talented trainers.</p>
	</div>
    <div class="banner-btn">
                <a href="<?php echo e(route('members.create')); ?>"><span></span>Join Us</a>
            </div>

</header>
<?php echo $__env->make('members.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WP\demo\resources\views/members/profile.blade.php ENDPATH**/ ?>