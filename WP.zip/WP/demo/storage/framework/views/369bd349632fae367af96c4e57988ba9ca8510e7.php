
<?php $__env->startSection('content'); ?>

<style>
	#service{
			width: 100%;
			padding-bottom: 70px 0;
			background-color: #efefef;
		}
		.service-box{
			width: 60%;
			display: flex;
			flex-wrap: wrap;
			justify-content: space-around;
			margin: auto;
		}
		.single-service{
			flex-basis: 48%;
			text-align: center;
			border-radius: 7px;
			margin-bottom: 20px;
			padding-top:30px;
			width: 10%;
			box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
 
		}

		.single-service img{
			width: 90%;
			border-radius: 7px;

		}
		.single-service:hover{
		transform: translateY(-45px);
		}

      .service-desc{
	        flex-basis: 48%;
		    text-align: center;
		    font-style: oblique;
		    border-radius: 15px;
		    margin-bottom: 20px;
		    width: 10%
		    top:10%;
		    color: #009688;
        }


</style>

<body id="service">
		<div class="title-text">
			<br><br>
			<p>Services</p>
			<h1>We Provide Better</h1>	
			<br>
		</div>
		<div class="service-box">
			<div class="single-service">
				<img src="images/service1.jpg">
						<div class="service-desc">
							<br>
							<h3>Cardiovascular Equipment</h3>
							<hr>
							<br>
							<p>Facilitates physical activity that the human body can utilize to promote good health, lose weight and even relieve stress.</p>
						</div>
			</div>
			<div class="single-service">
				<img src="images/service2.jpg">
			
						<div class="service-desc">
							<h3>Strength Training Equipment</h3>
							<hr>
							<p>Different types of Strength training are present like barbells and dumbbells, weight machines and other exercise machines, weighted clothing, resistance bands, gymnastics apparatus, Swiss balls</p>
						</div>
			</div>
			<div class="single-service">
				<img src="images/service3.jpg">
				
						<div class="service-desc">
							<h3>Group Fitness Class</h3>
							<hr>
							<p> Group fitness is a great way to get a workout in without having to think or plan</p>
						</div>
			</div>
			<div class="single-service">
				<img src="images/service4.jpg">
				
						<div class="service-desc">
							<h3>Other services</h3>
							<hr>
							<p>Technogym have provided us with the vast majority of our fitness equipment, so you can rest assured the kit you’ll be using – from cardio to resistance</p>
						</div>
			</div>


			
		</div>
		
	</body>
<?php echo $__env->make('members.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WP\demo\resources\views/members/service.blade.php ENDPATH**/ ?>